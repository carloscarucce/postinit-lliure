<?php 
require_once('api\fileup\inicio.php');
$pluginTable = PREFIXO."postinit";
?>