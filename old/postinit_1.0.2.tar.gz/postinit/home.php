<?php
require_once('conf.php');

$sql = "select * from ".$pluginTable." order by id desc";
$qry = mysql_query($sql);

echo "<div class='boxCenter900'><table class='table'>";
echo 
	"<tr>
		<th>ID</th>
		<th>Data</th>
		<th>Autor</th>
		<th>Mensagem</th>
		<th>Alterar</th>
		<th>Excluir</th>
	</tr>";
while ($rs = mysql_fetch_assoc($qry)){
	echo 
	"<tr>
		<td>".$rs['id']."</td>
		<td>".$rs['date']."</td>
		<td>".$rs['author']."</td>
		<td>".substr($rs['post'], 0, 30)."...</td>
		<td><a href='".$llAppHome."&p=form&action=edit&amp;id=".$rs['id']."'><img src='".$plgIcones."wrench.png'></a></td>
		<td><a href='".$llAppOnServer."&p=action&action=delete&amp;id=".$rs['id']."' onclick='return confirm(\"Esta certo disso?\")'><img src='".$plgIcones."trash.png'></a></td>
	</tr>";
}
echo "</table></div>";
?>