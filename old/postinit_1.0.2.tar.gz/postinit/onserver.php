<?php
require_once($llAppPasta.'/'.$_GET['p'].'.php');

?>