<?php
$pluginHome = "?app=postinit";
$pluginPasta = "plugins/postinit/";

$botoes = array(
		array('href' => $backReal, 'img' => $plgIcones.'br_prev.png', 'title' => $backNome),
		array('href' => $llAppHome.'&p=form&action=new', 'img' => $plgIcones.'sun.png', 'title' => 'Novo')
	);
	
echo app_bar('Postinit', $botoes);

require_once(( isset($_GET['p']) ? $_GET['p'] : 'home' ).".php");
?>